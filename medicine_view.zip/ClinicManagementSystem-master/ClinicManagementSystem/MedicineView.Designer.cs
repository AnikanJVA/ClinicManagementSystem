﻿namespace ClinicManagementSystem
{
    partial class MedicineView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SearchMed = new System.Windows.Forms.TextBox();
            this.Search = new System.Windows.Forms.Button();
            this.MedicineName = new System.Windows.Forms.Label();
            this.MedicineDesc = new System.Windows.Forms.Label();
            this.type = new System.Windows.Forms.Label();
            this.Quantity = new System.Windows.Forms.Label();
            this.Price = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.Update = new System.Windows.Forms.Button();
            this.ClentID = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SearchMed
            // 
            this.SearchMed.Location = new System.Drawing.Point(235, 83);
            this.SearchMed.Name = "SearchMed";
            this.SearchMed.Size = new System.Drawing.Size(251, 20);
            this.SearchMed.TabIndex = 1;
            this.SearchMed.Text = "Search Medicine";
            this.SearchMed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.SystemColors.Highlight;
            this.Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Search.FlatAppearance.BorderSize = 0;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Search.Location = new System.Drawing.Point(134, 82);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(93, 20);
            this.Search.TabIndex = 2;
            this.Search.Text = "Search";
            this.Search.UseVisualStyleBackColor = false;
            // 
            // MedicineName
            // 
            this.MedicineName.AutoSize = true;
            this.MedicineName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedicineName.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.MedicineName.Location = new System.Drawing.Point(129, 164);
            this.MedicineName.Name = "MedicineName";
            this.MedicineName.Size = new System.Drawing.Size(98, 15);
            this.MedicineName.TabIndex = 7;
            this.MedicineName.Text = "Medicine Name:";
            // 
            // MedicineDesc
            // 
            this.MedicineDesc.AutoSize = true;
            this.MedicineDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedicineDesc.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.MedicineDesc.Location = new System.Drawing.Point(101, 190);
            this.MedicineDesc.Name = "MedicineDesc";
            this.MedicineDesc.Size = new System.Drawing.Size(126, 15);
            this.MedicineDesc.TabIndex = 8;
            this.MedicineDesc.Text = "Medicine Description:";
            // 
            // type
            // 
            this.type.AutoSize = true;
            this.type.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.type.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.type.Location = new System.Drawing.Point(191, 215);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(36, 15);
            this.type.TabIndex = 9;
            this.type.Text = "Type:";
            // 
            // Quantity
            // 
            this.Quantity.AutoSize = true;
            this.Quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantity.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Quantity.Location = new System.Drawing.Point(173, 241);
            this.Quantity.Name = "Quantity";
            this.Quantity.Size = new System.Drawing.Size(54, 15);
            this.Quantity.TabIndex = 10;
            this.Quantity.Text = "Quantity:";
            // 
            // Price
            // 
            this.Price.AutoSize = true;
            this.Price.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Price.Location = new System.Drawing.Point(189, 268);
            this.Price.Name = "Price";
            this.Price.Size = new System.Drawing.Size(38, 15);
            this.Price.TabIndex = 11;
            this.Price.Text = "Price:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(235, 163);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(251, 20);
            this.textBox2.TabIndex = 12;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(235, 189);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(251, 20);
            this.textBox1.TabIndex = 13;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(235, 214);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(251, 20);
            this.textBox3.TabIndex = 14;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(235, 241);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(251, 20);
            this.textBox4.TabIndex = 15;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(235, 267);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(251, 20);
            this.textBox5.TabIndex = 16;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Update
            // 
            this.Update.BackColor = System.Drawing.SystemColors.Highlight;
            this.Update.FlatAppearance.BorderSize = 0;
            this.Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Update.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Update.Location = new System.Drawing.Point(281, 315);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(159, 27);
            this.Update.TabIndex = 17;
            this.Update.Text = "Update";
            this.Update.UseVisualStyleBackColor = false;
            // 
            // ClentID
            // 
            this.ClentID.AutoSize = true;
            this.ClentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClentID.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ClentID.Location = new System.Drawing.Point(538, 84);
            this.ClentID.Name = "ClentID";
            this.ClentID.Size = new System.Drawing.Size(59, 16);
            this.ClentID.TabIndex = 18;
            this.ClentID.Text = "Client ID:";
            // 
            // MedicineView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(705, 450);
            this.Controls.Add(this.ClentID);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.Price);
            this.Controls.Add(this.Quantity);
            this.Controls.Add(this.type);
            this.Controls.Add(this.MedicineDesc);
            this.Controls.Add(this.MedicineName);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.SearchMed);
            this.Name = "MedicineView";
            this.Text = "MedicineView";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox SearchMed;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Label MedicineName;
        private System.Windows.Forms.Label MedicineDesc;
        private System.Windows.Forms.Label type;
        private System.Windows.Forms.Label Quantity;
        private System.Windows.Forms.Label Price;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.Label ClentID;
    }
}