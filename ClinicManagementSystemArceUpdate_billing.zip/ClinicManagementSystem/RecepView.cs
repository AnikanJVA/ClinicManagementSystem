﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ClinicManagementSystem.LoginForm;

namespace ClinicManagementSystem
{
    public partial class RecepView : Form
    {
        public RecepView()
        {
            InitializeComponent();
        }

        private void ClientsButton_Click(object sender, EventArgs e)
        {

        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            Database.Instance.Connection.Close();
            loginForm.Show();
            this.Close();
        }

        private void AppointmentsButton_Click(object sender, EventArgs e)
        {

        }

        private void BillingButton_Click(object sender, EventArgs e)
        {
            AppointmentsButton.BackColor = Color.FromArgb(0, 148, 212);
            BillingTableButton.BackColor = Color.FromArgb(1, 34, 79); 

            tabControl1.Visible = false;
            CreateAppointmentButton.Visible = false;
            UpdateAppointmentButton.Visible = false;

            CreateBillingButton.Visible = true;
            BillingDGV.Visible = true;
        }

        private void CreateBillingButton_Click(object sender, EventArgs e)
        {
            BillingCreateUpdate billingCreateUpdate = new BillingCreateUpdate();
            Database.Instance.Connection.Close();
            billingCreateUpdate.Show();
            this.Close();

        }
    }
}
