﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string firstname = textBox1.Text;
            string middlename = textBox2.Text;
            string lastname = textBox3.Text;
            string dob = textBox4.Text;
            string contactNumber = textBox5.Text;
            string alternateContact = textBox6.Text;
            string email = textBox7.Text;
            string address = textBox8.Text;

            string sex = " ";
            if (radioButton1.Checked)
               sex = "Male";
            else if (radioButton2.Checked) sex = "Female";

            string summary = $"Patient Info: \n\n" + $"Name: {firstname}{middlename}{lastname} \n" + $"Date of Birth: {dob}\n" + $"Sex: {sex}\n" + $"Contact Number: {contactNumber}\n" + $"Alternate Contact Number:{alternateContact}\n + Address: {email}\n" + $"Address: {address}";
            MessageBox.Show(summary,"Patient Registered",
                MessageBoxButtons.OK, MessageBoxIcon.Information );
      
        }
    }
}
